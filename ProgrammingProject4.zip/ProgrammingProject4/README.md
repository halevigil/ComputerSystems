to compile the program, run:
make problem

to run the problem, run:
make run_problem