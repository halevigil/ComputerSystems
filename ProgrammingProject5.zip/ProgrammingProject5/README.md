to compile the program, run:
make problem

to run the problem, run:
make run_problem

./primes_control_run is the output from the single process calculating the primes from the first 100000 numbers, while ./primes is the output from splitting the task into 10 different processes. 