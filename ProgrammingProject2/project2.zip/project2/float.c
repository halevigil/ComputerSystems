#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "float.h"


int is_special ( float f ) {

    return 0;

}


float get_M  ( float f ) {
    
    return 0.0; 
}


int get_s ( float f ) {
	
	return 0;
}



int get_E ( float f ) {
	
    return 0;
}













      



    
    
